package my;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.LayoutManager;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyFrame3 extends JFrame {
	
	public MyFrame3() {
		
		JPanel jp = new JPanel();
		jp.setBackground(Color.orange);  // 판넬 배경색 변경
		LayoutManager lm = jp.getLayout();
		System.out.println(lm);
		
		setSize(300,200);
		getContentPane().setBackground(Color.YELLOW);
		setLocation(200, 300);
		// 2. 레이아웃(배치설정하기)
		
		setLayout(new BorderLayout());
		// 3. 컴포넌트 생성하기
		JButton button1 = new JButton("확인");
		button1.setBackground(Color.YELLOW);  // 버튼의 배경 변경
		JButton button2 = new JButton("취소");
		button2.setBackground(Color.GREEN);  // 버튼의 배경 변경
		
		// 4. 컴포넌트 판넬 컨테이너에 붙이기
		jp.add(button1);
		jp.add(button2);
		
		// 5. 판넬을 프레임에 붙이기
		add(jp);
		setVisible(true);
		setTitle("BorderLayout");
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}

	public static void main(String[] args) {
		MyFrame3 f = new MyFrame3();
		

	}

}
