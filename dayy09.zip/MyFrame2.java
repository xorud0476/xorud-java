package my;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyFrame2 extends JFrame {
	
	public MyFrame2() {
		//1. super("MyFrame");
		setSize(300,200);
		getContentPane().setBackground(Color.YELLOW);
		setLocation(200, 300);
		// 2. 레이아웃(배치설정하기)
		
		setLayout(new BorderLayout());
		// 3. 컴포넌트 생성하기
		JButton button1 = new JButton("동쪽");
		JButton button2 = new JButton("서쪽");
		JButton button3 = new JButton("남쪽");
		JButton button4 = new JButton("북쪽");
		JButton button5 = new JButton("가운데");
		// 4. 컴포넌트 컨테이너에 붙이기
		add(button1, BorderLayout.EAST);
		add(button2, BorderLayout.WEST);
		add(button3, BorderLayout.SOUTH);
		add(button4, BorderLayout.NORTH);
		add(button5, BorderLayout.CENTER);
		setVisible(true);
		setTitle("BorderLayout");
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}

	public static void main(String[] args) {
		MyFrame2 f = new MyFrame2();
		

	}

}
