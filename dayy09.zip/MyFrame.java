package my;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.LayoutManager;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyFrame extends JFrame {
	
	public MyFrame() {
		//1. super("MyFrame");
		setSize(300,200);
		getContentPane().setBackground(Color.YELLOW);
		setLocation(200, 300);
		// 2. 레이아웃(배치설정하기)
		//setLayout(new FlowLayout());
		LayoutManager lm = getLayout();
		System.out.println(lm);
		// 3. 컴포넌트 생성하기
		JButton button = new JButton("확인");
		JButton button2 = new JButton("취소");
		// 4. 컴포넌트 컨테이너에 붙이기
		this.add(button);
		this.add(button2);
		setVisible(true);
		setTitle("MyFrame");
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}

	public static void main(String[] args) {
		MyFrame f = new MyFrame();
		

	}

}

// 판넬의 디폴트는 프레임
// 프레임의 디폴트는 보더