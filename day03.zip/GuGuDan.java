package day03;

import java.util.*;

public class GuGuDan {

	public static void main(String[] args) {

		int n = 2;
		int i = 1;
		Scanner scan = new Scanner(System.in);
		// System.out.println("구구단 중에서 출력하고 싶은 단을 입력하시오:");
		// n = scan.nextInt();

		while (n <= 9) {
			//System.out.println(n);
			
			while (i <= 9) {
				System.out.println(n + "*" + i + "=" + n * i);
				i++;
			}
			i=1;
			n++;
		}

		/*while (i <= 9) {
			System.out.println(n + "*" + i + "=" + n * i);
			i++;
		} */

	}

}
