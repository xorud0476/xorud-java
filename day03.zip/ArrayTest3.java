package day03;

public class ArrayTest3 {

	public static void main(String[] args) {

		// 2차원 배열 선언 및 초기화
		int[][] list2 = {
				{10, 20, 30},
				{40, 50, 60},
				{70, 80, 90}
		};
		for(int j = 0; j<list2.length; j++) {
		
		for(int i = 0; i<list2[j].length; i++) {
			System.out.println("list2[" + j + "]["+i+"]="+list2[j][i]);
		}
		}
	
	}

}
