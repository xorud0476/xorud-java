package day03;
import java.util.Scanner;
public class Sum {
	
	public static void main(String[] args) {

		int n;
		System.out.println("숫자를 입력하세요:");
		Scanner scan = new Scanner(System.in);
		n = scan.nextInt();
		int sum = 0;
		while(n <= 100) {
			sum = sum + n;
			n++;
		}
		System.out.println("합계 = " + sum);
		
	}

}
