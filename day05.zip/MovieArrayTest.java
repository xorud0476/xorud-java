package day05;

import java.util.ArrayList;
import java.util.Scanner;

public class MovieArrayTest {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		// 동적 객체 배열 저장 할 ArrayList 객체 생성
		ArrayList<Movie> alist = new ArrayList<Movie>();

		System.out.printf("영화제목: ");
		String title = scan.nextLine();
		System.out.printf("영화감독: ");
		String director = scan.nextLine();

		alist.add(new Movie(title, director));
		
		for (Movie m1: alist) {

			System.out.print("{" + m1.title + "}" + "{" + m1.director + "}");

		}

	}

}
