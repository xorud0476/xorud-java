package day05;

class Student {
	// 이름, 학번, 나이 (정보 은닉(캡슐화))
	private String name;
	private String rollno;
	private int age;
	static int count = 0;
	
	// 기본 생성자
	public Student() {
		count++;
	}
	
	// 인자 생성자
	public Student(String name, String rollno, int age) {
		this.name = name;
		this.rollno = rollno;
		this.age = age;
		count++;
	}

	// set 메소드
	public void setName(String name) {
		this.name = name;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public void setAge(int age) {
		this.age = age;
	}
	// get 메소드
	public String getName() {
		return name;
	}
	public String getRollno() {
		return rollno;
	}
	public int getAge() {
		return age;
	}
	
	
} 

public class StudentTest {

	public static void main(String[] args) {

		Student Kim = new Student("Kim", "20180001", 20);
		Student Lee = new Student();
		
		Student sarray[] = new Student[3];
		sarray[0] = Kim;
		sarray[1] = Lee;
		sarray[2] = new Student("Park", "20190001", 19);
		
		for(Student s : sarray) {
			System.out.println(s.getName());
			System.out.println(s.getRollno());
			System.out.println(s.getAge());
		}
		
		System.out.println("학생의 이름:" + Kim.getName());
		System.out.println("학생의 학번:" + Kim.getRollno());
		System.out.println("학생의 나이:" + Kim.getAge());
		
		Lee.setName("Lee");
		Lee.setRollno("20170001");
		Lee.setAge(25);
		System.out.println("학생의 이름:" + Lee.getName());
		System.out.println("학생의 학번:" + Lee.getRollno());
		System.out.println("학생의 나이:" + Lee.getAge());
		System.out.println(Student.count);   // 정적 변수 사용은 클래스 이름으로 접근
	}

}
