package day05;

import java.util.Scanner;

public class MovieArrayTest2 {

	public static void main(String[] args) {

		// Movie 객체 생성
		Movie m1 = new Movie();
		Movie m2 = new Movie();

		Scanner scan = new Scanner(System.in);
		Movie m3;
		Movie[] marray = new Movie[2];
		
		for (int i = 0; i < marray.length; i++) {
			System.out.printf("영화제목: ");
			String title = scan.nextLine();
			System.out.printf("영화감독: ");
			String director = scan.nextLine();

			m3 = new Movie(title, director);
			marray[i] = m3;
		}
		for (int i = 0; i < marray.length; i++) {
			
			System.out.print("{" + marray[i].title + "}" + "{" + marray[i].director + "}");
			
		}
		
		

	}

}
