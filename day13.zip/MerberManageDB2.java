package day13;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class MerberManageDB2 {
	
	public static void main(String[] args) {
		String url = "jdbc:mysql://localhost:3306/mydb";
		String id = "root";
		String pwd = "1234";
		
		// 1. JDBC 드라이버 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
		// 2. 데이터베이스 연결
			try {
				Connection con = DriverManager.getConnection(url, id, pwd);
		
		// 3. 데이터 조작 (statement 객체 생성)
			// String sql = "SELECT * FROM member";
				String sql = "SELECT id, email, dept FROM member WHERE username=?";
				PreparedStatement psmt = con.prepareStatement(sql);
				psmt.setString(1, "김태경");
				
				
		// 4. statement 전송하기와 5. 결과 받기
		// 조회 전송 -> executeQuery() 결과는 -> ResultSet로 반환됨
				ResultSet rs = psmt.executeQuery();
				int rid = -1;
				String uname, udpt, da, uemail;
				
				while(rs.next()) {
					rid = rs.getInt("id");
		//			uname = rs.getString("username");
					udpt = rs.getString("dept");
		//			java.sql.Date d = rs.getDate("birth");
		//			da = d+"";
					uemail = rs.getString("email");

					System.out.println("----학생멤버조회----");
					System.out.println("아이디: " + rid);
		//			System.out.println("이름: " + uname);
					System.out.println("학과: " + udpt);
		//			System.out.println("생일: " + da);
					System.out.println("이메일: " + uemail);
				}
				
				
				
		// 6. 연결 해제
				con.close();
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			
			
			
			
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		
		
	}

}
