package day13;

import java.util.ArrayList;

public class MemberTest {

	public static void main(String[] args) {
		
		ArrayList<MemberDTO> mtolist = new ArrayList<MemberDTO>();

		MemberDAO mdao = new MemberDAO();

		MemberDTO mdto = new MemberDTO(1113, "강길동", "정보통신", "kang@ab.c");

		int r = mdao.insertDB(mdto);

		if (r == 1) {
			System.out.println("입력성공");
			////////////////////////////
			mtolist = mdao.selectALL();
			////////////////////////////
			for(MemberDTO m:mtolist) {
				System.out.println("--회원조회결과(all)--");
				System.out.println("아이디: " + m.getId());
				System.out.println("이름: " + m.getUsername());
				System.out.println("학과: " + m.getDept());
				System.out.println("생일: " + m.getBirth());
				System.out.println("이메일: " + m.getEmail());
			}

		} else {
			System.out.println("입력실패");
		}

	}

}
