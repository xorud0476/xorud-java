package day10.my;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class RockPaperScissor extends JFrame implements ActionListener {

	final int ROCK = 0;
	final int PAPER = 1;
	final int SCISSOR = 2;
	private JPanel panel;
	private JLabel output, information;
	private JButton rock, paper, scissor;

	// 생성자
	public RockPaperScissor() {
		setTitle("가위, 바위, 보");
		setSize(400, 150);
		panel = new JPanel();
		panel.setLayout(new GridLayout(0, 3));
		information = new JLabel("아래의 버튼중에서 하나 클릭하시오!");
		output = new JLabel("Good Luck!");
		rock = new JButton("0: 바위");
		paper = new JButton("1: 보");
		scissor = new JButton("2: 가위");

		// 이벤트 처리 객체 등록하기ㅣ
		rock.addActionListener(this);
		paper.addActionListener(this);
		scissor.addActionListener(this);

		panel.add(rock);
		panel.add(paper);
		panel.add(scissor);

		add(information, BorderLayout.NORTH);
		add(panel, BorderLayout.CENTER);
		add(output, BorderLayout.SOUTH);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);

	}

	public static void main(String[] args) {

		new RockPaperScissor();

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		JButton obj = (JButton) e.getSource();

		int user = Integer.parseInt("" + obj.getText().charAt(0));
		Random random = new Random();
		int computer = random.nextInt(3);
		if (user == computer)
			output.setText("인간과컴퓨터가비겼음");
		else if (user == (computer + 1) % 3)
			output.setText("인간: " + user + " 컴퓨터: " + computer + "인간승리");
		else
			output.setText("인간: " + user + " 컴퓨터: " + computer + "컴퓨터승리");

	}

}
