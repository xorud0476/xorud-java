package day10.my;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MyFrame4 extends JFrame {
	class MyPanel extends JPanel {
		protected void paintComponent(Graphics g) { 
			super.paintComponent(g);
			g.drawOval(60, 50, 60, 60);
			g.drawRect(120, 50, 60, 60);
			g.setColor(Color.BLUE);
			g.fillOval(180, 50, 60, 60);
			g.fillRect(240, 50, 60, 60);
		}
	}

	public MyFrame4() {
		  setTitle("Basic Painting");
		  setSize(600, 200);
		  add(new MyPanel());
		  setVisible(true);
		  setDefaultCloseOperation(EXIT_ON_CLOSE);
		 }

	public static void main(String[] args) {
		MyFrame4 f = new MyFrame4();
	}



}
