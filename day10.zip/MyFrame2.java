package day10.my;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JFrame;

public class MyFrame2 extends JFrame implements MouseListener {
	public MyFrame2() {
		addMouseListener(this);
		setSize(600, 600);
		setLayout(null);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public void mouseClicked(MouseEvent e) {
		Graphics g = getGraphics();
		g.setColor(Color.RED);
		g.fillOval(e.getX() - 30, e.getY() - 30, 20, 20);
	}

	public static void main(String[] args) {

		MyFrame2 mf2 = new MyFrame2();
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	class MyAdapter extends MouseMotionAdapter {
		@Override
		public void mouseDragged(MouseEvent e) {
			super.mouseDragged(e);
		}
	}

}
