package day11;

import java.net.*;
import java.io.*;
import java.util.*;

public class ServerEx {

	ServerSocket ser;
	Socket sock;
	BufferedWriter pw;
	BufferedReader br;

	public ServerEx() {
		try {
			ser = new ServerSocket(8888);

			System.out.println("대기중");
			sock = ser.accept();
			System.out.println("클라이언트와 연결 성공");

			Scanner scanner = new Scanner(System.in);

			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			pw = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
			while (true) {
				String inputMessage = br.readLine(); // 클라이언트로부터 한 행 읽기
				if (inputMessage.equalsIgnoreCase("bye")) {
					System.out.println("클라이언트에서 bye로 연결을 종료하였음");
					break; // "bye"를 받으면 연결 종료
				}
				System.out.println("클라이언트: " + inputMessage);
				System.out.print("보내기>>"); // 프롬프트
				String outputMessage = scanner.nextLine(); // 키보드에서 한 행 읽기
				pw.write(outputMessage + "\n"); // 키보드에서 읽은 문자열 전송
				pw.flush(); // out의 스트림 버퍼에 있는 모든 문자열 전송
			}

		}

		catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {

		new ServerEx();

	}
}
