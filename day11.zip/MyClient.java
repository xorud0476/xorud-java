package day11;
import java.io.*;
import java.net.*;
public class MyClient {

	Socket sock;
	BufferedReader br;
	
	public MyClient() {
		try {
			sock = new Socket("localhost",9999);
			System.out.println("서버 연결 성공");
			
			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			
			String data = "";
			
			while((data = br.readLine())!=null) {
				System.out.println("서버로부터>>>>>" + data);
			}
			
			sock.close();
			br.close();
			
		} catch (UnknownHostException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		
		new MyClient();
		
	}

}
