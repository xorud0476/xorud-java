package day11;
import java.io.*;
public class CopyFile {

	public static void main(String[] args) {
		try {
			
			FileReader fr = new FileReader("input.txt");
			FileWriter fw = new FileWriter("ouput.txt");
			
			int c;
			while((c = fr.read())!=-1) {
				fw.write(c);
			}
			
			fr.close();
			fw.close();

		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
