package day06;

public class Teacher extends Person {

	String tid; // 교번
	public Teacher() {
		super();
	}

	// 메소드 오버라이딩
	public void showInfo() {
		super.showInfo();
		System.out.println(" 교번: " + tid);
	}
}
