package day06;
import java.util.*;
public class SchoolpApp {

	public static void main(String[] args) {

		Person p1 = new Staff(); // 다형성1
		Person p2 = new Student(); // 다형성2
		
		p1.name = "장직원";
		p1.addr = "장직원 주소";
		p1.age  = 30;		
		
		Student s1 = new Student();
		s1.name = "김학생";
		s1.addr = "김학생 주소";
		s1.age = 21;
		s1.sid = "202011";
		
		Teacher t1 = new Teacher();
		t1.name = "박교사";
		t1.addr = "박교사 주소";
		t1.age = 30;
		t1.tid = "111222";
		
		
		
		ArrayList<Person> alist = new ArrayList<Person> ();
		
		alist.add(p1);
		alist.add(p2);
		alist.add(t1);
		alist.add(s1);
		
		for(Person p:alist) {
			p.showInfo();
		}
		
		
	}

}
