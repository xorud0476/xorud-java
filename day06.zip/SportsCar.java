package day06;

public class SportsCar extends Car {

	boolean turbo;
	
	public void setTurbo(boolean flag) {
		turbo = flag;
	}
	
}
