package day06;

public class User {

	// 사용자
	String id, password;

	// 기본 생성자
	public User() {
		
	}

	// 인자 생성자
	public User(String id, String password) {
		this.id = id;
		this.password = password;
	}
	
	
	
	// 메뉴 메소드
	public void showUser() {
		System.out.println("id: "+ id);
		System.out.println("password: " + password);
		
	}
	
	
}
