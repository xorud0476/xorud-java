package day06;

public class Student extends Person { // 상속하기
	
	String sid;  // 학번
	public Student() {
		super();
	}
	
	// 메소드 오버라이딩
	public void showInfo() {
		super.showInfo();
		System.out.println(" 학번: " + sid);
	}
	

}
