package day06;

import java.util.*;

public class UserTest {

	static ArrayList<User> alist = new ArrayList<User>();
	static Scanner scan = new Scanner(System.in);
	static String id = "", password = "";

	public static void menu() {
		System.out.println("===============");
		System.out.println("1. Sign Up");
		System.out.println("2. Login");
		System.out.println("3. Print All Users");
		System.out.println("4. Exit");
		System.out.println("===============");
	}

	public static void login() {
		Scanner scan = new Scanner(System.in);
		System.out.println("로그인");
		System.out.println("1. 아이디 입력: ");
		id = scan.next();
		System.out.println("2. 패스워드 입력: ");
		password = scan.next();
	}

	public static void main(String[] args) {

		// 정적 메소드 호출
		

		User user1;

		while (true) {
			UserTest.menu();

			System.out.print("번호를 입력하시오: ");
			int num = scan.nextInt();

			switch (num) {
			case 1:
				System.out.print("id: ");
				id = scan.next();
				System.out.print("password: ");
				password = scan.next();
				user1 = new User(id, password);
				alist.add(user1);
				break;
			case 2: // 로그인
				UserTest.login();
				// 입력한 아이디와 비번을 데이터베이스에 저장된 아이디와 비번과 일치하는지 검사
				for (User u : alist) {
					String uId = u.id;
					String uPd = u.password;
					if (uId.equals(id) && uPd.equals(password))
						System.out.println("로그인 성공");
					else
						System.out.println("로그인 실패");
				}

				break;

			case 3:
				for (User u : alist)
					System.out.println("{" + u.id + "," + u.password + "}");
				break;

			case 4:
				System.exit(0);
				break;

			default:
				System.out.println("해당 번호가 존재하지 않습니다. 1~4번까지만 입력하세요");
				break;
			}

		}
	}
}
