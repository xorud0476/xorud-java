package day04;

class Account{
	// 필드 은닉화
	private String regaccount;  // 계좌번호
	private String name;   // 계좌주인이름
	private int balance;   // 계좌 잔액
	
	// 기본 생성자
	public Account() {
		
	}
	
	// 인자 생성자
	public Account(String reg, String name, int balance) {
		regaccount = reg;		
		this.name = name;
		this.balance = balance;
	}
	
	// setter 메소드(설정자)
	public void setRegaccount(String reg) {
		regaccount = reg;		
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	// getter 메소드(접근자)
	public String getRegaccount() {
		return regaccount;
	}
	public String getName() {
		return name;
	}
	public int getBalance() {
		return balance;
	}
	
}


public class AccountTest {

	public static void main(String[] args) {

		Account hana = new Account("123-456-789", "홍길동", 10000);
		System.out.println(hana.getRegaccount());
		System.out.println(hana.getName());
		System.out.println(hana.getBalance());
		
		hana.setBalance(1000);
		System.out.println(hana.getBalance());
		
			
	}

	
	
	
	
	
}
