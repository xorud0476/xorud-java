package day04;
import java.util.*;
public class CircleTVTest {

	public static void main(String[] args) {

		// 참조형 변수 
		Circle obj;
		
		TV obj2;
		
		
		// 객체 생성 하기 (생성자 호출)
		obj = new Circle(); // 기본 생성자
		
		obj2 = new TV();

		Circle obj3 = new Circle();
		
		TV tv1 = new TV(5, 0, true);
		
		// 멤버 변수 (필드)속성 초기화
		obj.radius = 12.5;
		obj.color = "빨강";
		
		//obj2.chanel = 9;
		//obj2.volume = 1;
		obj2.setChanel(9);
		obj2.setVolume(1);
		
		obj3.setRadius(13.5);
		
		double area = obj.calcArea();
		System.out.println("반지름이" + obj.radius + "인 원의 면적입니다.");
		
		obj2.changeChanel(13);
		obj2.volumeUp();
		obj2.turnOff();
		
		ArrayList<TV> alist = new ArrayList<>();
		ArrayList<Circle> alist2 = new ArrayList<>();
		
		alist.add(obj2);
		alist.add(tv1);
		alist2.add(obj);
		alist2.add(obj3);
		
		for(TV t : alist) {
			System.out.println(t.getChanel());
		}
		
		for(Circle c : alist2) {
			System.out.println(c.radius);
			System.out.println(c.calcArea());
		}
		
	}

}
