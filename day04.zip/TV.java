package day04;

public class TV {
	
		// 필드    캡슐화
		private int chanel;
		private int volume;
		private boolean onOff;
		
		// 기본 생성자
		public TV() {}
		
		// 인자 생성자
		public TV(int chanel, int volume, boolean onOff) {
			this.chanel = chanel;
			this.volume = volume;
			this.onOff = onOff;
		}
		
		// setter 메소드 정의
		void setChanel(int chanel) {
			this.chanel = chanel;
		}
		void setVolume(int volume) {
			this.volume = volume;
		}
		void setOnOff(boolean onOff) {
			this.onOff = onOff;
		}
		
		// getter 메소드 정의
		int getChanel() {
			return chanel;
		}
		int getVolume() {
			return volume;
		}
		boolean getOnOff() {
			return onOff;
		}
		
		// 메소드
		void turnOn() {
			System.out.println("TV전원켜기");
		}
		
		void turnOff() {
			System.out.println("TV전원끄기");
		}
		
		void changeChanel(int c) {
			chanel = c;
			System.out.println("채널이 변경됨" + chanel + "번 채널로 변경");
		}
		
		void volumeUp() {
			volume = volume +10;
			System.out.println("볼륨이 변경됨" + volume + "으로 변경");
		}
		
		void volumeDown() {
			volume = volume -10;
			System.out.println("볼륨이 변경됨" + volume + "으로 변경");
	}


}