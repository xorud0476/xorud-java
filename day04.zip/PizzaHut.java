package day04;

public class PizzaHut {

	public static void main(String[] args) {

		Pizza pizza = new Pizza();
		Pizza pizza1 = new Pizza();
		Pizza pizza2 = new Pizza(10, "페퍼로니피자");
		//pizza.type = "불고기 피자";
		//pizza.size = 12;
		pizza1.type = "치즈피자";
		pizza1.size = 5;
		
	
		
		System.out.println(pizza.type + pizza.size);
		System.out.println(pizza1.type + pizza1.size);
		System.out.println(pizza2.type + pizza2.size);
		
	
		
	}

}
