package day04;

public class Person {

	private String name, gender;
	private int age;
	public Person() {}
	
	// 인자 생성자
	public Person(String name, String gender, int age) {
		this.name = name;
		this.gender = gender;
		this.age = age;
	}
	
	// setter 메소드 정의
	void setName(String name) {
		this.name = name;
	}
	void setGender(String gender) {
		this.gender = gender;
	}
	void setAge(int age) {
		this.age = age;
	}
	
	// getter 메소드 정의
	String getName() {
		return name;
	}
	String getGender() {
		return gender;
	}
	int getAge() {
		return age;
	}
	
	// 메소드
	void personInfo() {
		System.out.println("-----------------");
		System.out.println("이름:" + name);
		System.out.println("성별:" + gender);
		System.out.println("나이:" + age);
	}
	
	// 오버로딩(중복정의) : 메소드 이름은 같지만 매개변수의 갯수, 타입이 다르면 됨
	void personInfo(String name) {
		System.out.println("-----------------");
		this.name = name;
		System.out.println("이름:" + this.name);
		System.out.println("성별:" + this.gender);
		System.out.println("나이:" + this.age);
	}
	
	// 이름을 매개변수로 받아서 그 이름을 그대로 출력하는 메소드 정의하기
	void yourName(String n) {
		System.out.println("당신의 이름은 :" + n + "입니다.");
	}
	
	// 나이를 매개변수로 받아서 현재 나이에 매개변수로 받은 나이를 합산해서 반환하는 메소드 정의
	int yourAge(int age) {
		return (this.age + age);
	}
	
}
