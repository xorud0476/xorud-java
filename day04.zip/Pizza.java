package day04;

public class Pizza {

	int size;
	String type;
	
	
	// 기본 생성자 : 반환형은 명시 하지 않는다. 이름은 클래스 이름과 같다.
	public Pizza() {
		size = 12;
		type = "슈퍼슈프림";
	}
		
	
		
		// 인자 생성자 :
		public Pizza(int s, String type) {
			size = s;
			this.type = type;
		}
	}
	
	
	
	
	

