package day07;

public class ShapeTest {

	public static void main(String[] args) {
		Shape s = new Circle(); // 업캐스팅
		Rectangle rect = new Rectangle();
		// 추상화는 객체 생성 불가 Shape s1 = new Shape();
		
		Circle c = new Circle();
		
		s.draw();
		rect.draw();
		c.print();
		
		
		
	}

}
