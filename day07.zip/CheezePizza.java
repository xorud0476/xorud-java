package day07;

public class CheezePizza extends Pizza{

	void make() {
		System.out.println("치즈 피자를 만듭니다.");
		
	}
	
}
